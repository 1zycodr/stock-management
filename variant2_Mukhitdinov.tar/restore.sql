--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.10 (Debian 12.10-1.pgdg110+1)
-- Dumped by pg_dump version 14.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE stock_system;
--
-- Name: stock_system; Type: DATABASE; Schema: -; Owner: pguser
--

CREATE DATABASE stock_system WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.utf8';


ALTER DATABASE stock_system OWNER TO pguser;

\connect stock_system

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: app_user; Type: TABLE; Schema: public; Owner: pguser
--

CREATE TABLE public.app_user (
    id bigint NOT NULL,
    first_name character varying(255),
    last_name character varying(255),
    password character varying(255) NOT NULL,
    username character varying(255) NOT NULL,
    version bigint,
    CONSTRAINT app_user_id_check CHECK ((id <= 100000))
);


ALTER TABLE public.app_user OWNER TO pguser;

--
-- Name: app_user_id_seq; Type: SEQUENCE; Schema: public; Owner: pguser
--

CREATE SEQUENCE public.app_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.app_user_id_seq OWNER TO pguser;

--
-- Name: app_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pguser
--

ALTER SEQUENCE public.app_user_id_seq OWNED BY public.app_user.id;


--
-- Name: payment_receipt; Type: TABLE; Schema: public; Owner: pguser
--

CREATE TABLE public.payment_receipt (
    id bigint NOT NULL,
    CONSTRAINT payment_receipt_id_check CHECK ((id <= 100000))
);


ALTER TABLE public.payment_receipt OWNER TO pguser;

--
-- Name: payment_receipt_id_seq; Type: SEQUENCE; Schema: public; Owner: pguser
--

CREATE SEQUENCE public.payment_receipt_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.payment_receipt_id_seq OWNER TO pguser;

--
-- Name: payment_receipt_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pguser
--

ALTER SEQUENCE public.payment_receipt_id_seq OWNED BY public.payment_receipt.id;


--
-- Name: privilege; Type: TABLE; Schema: public; Owner: pguser
--

CREATE TABLE public.privilege (
    id bigint NOT NULL,
    name character varying(255)
);


ALTER TABLE public.privilege OWNER TO pguser;

--
-- Name: privilege_id_seq; Type: SEQUENCE; Schema: public; Owner: pguser
--

CREATE SEQUENCE public.privilege_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.privilege_id_seq OWNER TO pguser;

--
-- Name: privilege_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pguser
--

ALTER SEQUENCE public.privilege_id_seq OWNED BY public.privilege.id;


--
-- Name: product; Type: TABLE; Schema: public; Owner: pguser
--

CREATE TABLE public.product (
    id bigint NOT NULL,
    description character varying(255),
    price integer NOT NULL,
    title character varying(255),
    CONSTRAINT product_id_check CHECK ((id <= 100000)),
    CONSTRAINT product_price_check CHECK ((price >= 0))
);


ALTER TABLE public.product OWNER TO pguser;

--
-- Name: product_id_seq; Type: SEQUENCE; Schema: public; Owner: pguser
--

CREATE SEQUENCE public.product_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.product_id_seq OWNER TO pguser;

--
-- Name: product_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pguser
--

ALTER SEQUENCE public.product_id_seq OWNED BY public.product.id;


--
-- Name: purchase; Type: TABLE; Schema: public; Owner: pguser
--

CREATE TABLE public.purchase (
    id bigint NOT NULL,
    address character varying(255),
    status character varying(255) DEFAULT 'PAYMENT'::character varying,
    purchase_type character varying(255),
    user_id bigint,
    stock_id bigint,
    CONSTRAINT purchase_id_check CHECK ((id <= 100000))
);


ALTER TABLE public.purchase OWNER TO pguser;

--
-- Name: purchase_id_seq; Type: SEQUENCE; Schema: public; Owner: pguser
--

CREATE SEQUENCE public.purchase_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.purchase_id_seq OWNER TO pguser;

--
-- Name: purchase_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pguser
--

ALTER SEQUENCE public.purchase_id_seq OWNED BY public.purchase.id;


--
-- Name: purchase_products; Type: TABLE; Schema: public; Owner: pguser
--

CREATE TABLE public.purchase_products (
    id bigint NOT NULL,
    quantity bigint NOT NULL,
    product_id bigint,
    purchase_id bigint,
    stock_id bigint,
    CONSTRAINT purchase_products_id_check CHECK ((id <= 100000)),
    CONSTRAINT purchase_products_quantity_check CHECK ((quantity >= 1))
);


ALTER TABLE public.purchase_products OWNER TO pguser;

--
-- Name: purchase_products_id_seq; Type: SEQUENCE; Schema: public; Owner: pguser
--

CREATE SEQUENCE public.purchase_products_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.purchase_products_id_seq OWNER TO pguser;

--
-- Name: purchase_products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pguser
--

ALTER SEQUENCE public.purchase_products_id_seq OWNED BY public.purchase_products.id;


--
-- Name: role; Type: TABLE; Schema: public; Owner: pguser
--

CREATE TABLE public.role (
    id bigint NOT NULL,
    name character varying(255)
);


ALTER TABLE public.role OWNER TO pguser;

--
-- Name: role_id_seq; Type: SEQUENCE; Schema: public; Owner: pguser
--

CREATE SEQUENCE public.role_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.role_id_seq OWNER TO pguser;

--
-- Name: role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pguser
--

ALTER SEQUENCE public.role_id_seq OWNED BY public.role.id;


--
-- Name: roles_privileges; Type: TABLE; Schema: public; Owner: pguser
--

CREATE TABLE public.roles_privileges (
    role_id bigint NOT NULL,
    privilege_id bigint NOT NULL
);


ALTER TABLE public.roles_privileges OWNER TO pguser;

--
-- Name: stock; Type: TABLE; Schema: public; Owner: pguser
--

CREATE TABLE public.stock (
    id bigint NOT NULL,
    address character varying(255),
    title character varying(255),
    CONSTRAINT stock_id_check CHECK ((id <= 100000))
);


ALTER TABLE public.stock OWNER TO pguser;

--
-- Name: stock_id_seq; Type: SEQUENCE; Schema: public; Owner: pguser
--

CREATE SEQUENCE public.stock_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.stock_id_seq OWNER TO pguser;

--
-- Name: stock_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pguser
--

ALTER SEQUENCE public.stock_id_seq OWNED BY public.stock.id;


--
-- Name: stock_products; Type: TABLE; Schema: public; Owner: pguser
--

CREATE TABLE public.stock_products (
    id bigint NOT NULL,
    quantity bigint NOT NULL,
    product_id bigint,
    stock_id bigint,
    CONSTRAINT stock_products_id_check CHECK ((id <= 100000)),
    CONSTRAINT stock_products_quantity_check CHECK ((quantity >= 1))
);


ALTER TABLE public.stock_products OWNER TO pguser;

--
-- Name: stock_products_id_seq; Type: SEQUENCE; Schema: public; Owner: pguser
--

CREATE SEQUENCE public.stock_products_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.stock_products_id_seq OWNER TO pguser;

--
-- Name: stock_products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pguser
--

ALTER SEQUENCE public.stock_products_id_seq OWNED BY public.stock_products.id;


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: pguser
--

CREATE TABLE public.user_roles (
    user_id bigint NOT NULL,
    role_id bigint NOT NULL
);


ALTER TABLE public.user_roles OWNER TO pguser;

--
-- Name: app_user id; Type: DEFAULT; Schema: public; Owner: pguser
--

ALTER TABLE ONLY public.app_user ALTER COLUMN id SET DEFAULT nextval('public.app_user_id_seq'::regclass);


--
-- Name: payment_receipt id; Type: DEFAULT; Schema: public; Owner: pguser
--

ALTER TABLE ONLY public.payment_receipt ALTER COLUMN id SET DEFAULT nextval('public.payment_receipt_id_seq'::regclass);


--
-- Name: privilege id; Type: DEFAULT; Schema: public; Owner: pguser
--

ALTER TABLE ONLY public.privilege ALTER COLUMN id SET DEFAULT nextval('public.privilege_id_seq'::regclass);


--
-- Name: product id; Type: DEFAULT; Schema: public; Owner: pguser
--

ALTER TABLE ONLY public.product ALTER COLUMN id SET DEFAULT nextval('public.product_id_seq'::regclass);


--
-- Name: purchase id; Type: DEFAULT; Schema: public; Owner: pguser
--

ALTER TABLE ONLY public.purchase ALTER COLUMN id SET DEFAULT nextval('public.purchase_id_seq'::regclass);


--
-- Name: purchase_products id; Type: DEFAULT; Schema: public; Owner: pguser
--

ALTER TABLE ONLY public.purchase_products ALTER COLUMN id SET DEFAULT nextval('public.purchase_products_id_seq'::regclass);


--
-- Name: role id; Type: DEFAULT; Schema: public; Owner: pguser
--

ALTER TABLE ONLY public.role ALTER COLUMN id SET DEFAULT nextval('public.role_id_seq'::regclass);


--
-- Name: stock id; Type: DEFAULT; Schema: public; Owner: pguser
--

ALTER TABLE ONLY public.stock ALTER COLUMN id SET DEFAULT nextval('public.stock_id_seq'::regclass);


--
-- Name: stock_products id; Type: DEFAULT; Schema: public; Owner: pguser
--

ALTER TABLE ONLY public.stock_products ALTER COLUMN id SET DEFAULT nextval('public.stock_products_id_seq'::regclass);


--
-- Name: 16846; Type: BLOB; Schema: -; Owner: pguser
--

SELECT pg_catalog.lo_create('16846');


ALTER LARGE OBJECT 16846 OWNER TO pguser;

--
-- Name: 16847; Type: BLOB; Schema: -; Owner: pguser
--

SELECT pg_catalog.lo_create('16847');


ALTER LARGE OBJECT 16847 OWNER TO pguser;

--
-- Data for Name: app_user; Type: TABLE DATA; Schema: public; Owner: pguser
--

COPY public.app_user (id, first_name, last_name, password, username, version) FROM stdin;
\.
COPY public.app_user (id, first_name, last_name, password, username, version) FROM '$$PATH$$/3065.dat';

--
-- Data for Name: payment_receipt; Type: TABLE DATA; Schema: public; Owner: pguser
--

COPY public.payment_receipt (id) FROM stdin;
\.
COPY public.payment_receipt (id) FROM '$$PATH$$/3067.dat';

--
-- Data for Name: privilege; Type: TABLE DATA; Schema: public; Owner: pguser
--

COPY public.privilege (id, name) FROM stdin;
\.
COPY public.privilege (id, name) FROM '$$PATH$$/3069.dat';

--
-- Data for Name: product; Type: TABLE DATA; Schema: public; Owner: pguser
--

COPY public.product (id, description, price, title) FROM stdin;
\.
COPY public.product (id, description, price, title) FROM '$$PATH$$/3071.dat';

--
-- Data for Name: purchase; Type: TABLE DATA; Schema: public; Owner: pguser
--

COPY public.purchase (id, address, status, purchase_type, user_id, stock_id) FROM stdin;
\.
COPY public.purchase (id, address, status, purchase_type, user_id, stock_id) FROM '$$PATH$$/3073.dat';

--
-- Data for Name: purchase_products; Type: TABLE DATA; Schema: public; Owner: pguser
--

COPY public.purchase_products (id, quantity, product_id, purchase_id, stock_id) FROM stdin;
\.
COPY public.purchase_products (id, quantity, product_id, purchase_id, stock_id) FROM '$$PATH$$/3075.dat';

--
-- Data for Name: role; Type: TABLE DATA; Schema: public; Owner: pguser
--

COPY public.role (id, name) FROM stdin;
\.
COPY public.role (id, name) FROM '$$PATH$$/3077.dat';

--
-- Data for Name: roles_privileges; Type: TABLE DATA; Schema: public; Owner: pguser
--

COPY public.roles_privileges (role_id, privilege_id) FROM stdin;
\.
COPY public.roles_privileges (role_id, privilege_id) FROM '$$PATH$$/3078.dat';

--
-- Data for Name: stock; Type: TABLE DATA; Schema: public; Owner: pguser
--

COPY public.stock (id, address, title) FROM stdin;
\.
COPY public.stock (id, address, title) FROM '$$PATH$$/3080.dat';

--
-- Data for Name: stock_products; Type: TABLE DATA; Schema: public; Owner: pguser
--

COPY public.stock_products (id, quantity, product_id, stock_id) FROM stdin;
\.
COPY public.stock_products (id, quantity, product_id, stock_id) FROM '$$PATH$$/3082.dat';

--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: pguser
--

COPY public.user_roles (user_id, role_id) FROM stdin;
\.
COPY public.user_roles (user_id, role_id) FROM '$$PATH$$/3083.dat';

--
-- Name: app_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pguser
--

SELECT pg_catalog.setval('public.app_user_id_seq', 3, true);


--
-- Name: payment_receipt_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pguser
--

SELECT pg_catalog.setval('public.payment_receipt_id_seq', 1, false);


--
-- Name: privilege_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pguser
--

SELECT pg_catalog.setval('public.privilege_id_seq', 3, true);


--
-- Name: product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pguser
--

SELECT pg_catalog.setval('public.product_id_seq', 3, true);


--
-- Name: purchase_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pguser
--

SELECT pg_catalog.setval('public.purchase_id_seq', 12, true);


--
-- Name: purchase_products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pguser
--

SELECT pg_catalog.setval('public.purchase_products_id_seq', 14, true);


--
-- Name: role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pguser
--

SELECT pg_catalog.setval('public.role_id_seq', 3, true);


--
-- Name: stock_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pguser
--

SELECT pg_catalog.setval('public.stock_id_seq', 5, true);


--
-- Name: stock_products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pguser
--

SELECT pg_catalog.setval('public.stock_products_id_seq', 5, true);


--
-- Data for Name: BLOBS; Type: BLOBS; Schema: -; Owner: -
--

\i $$PATH$$/3086.dat

--
-- Name: app_user app_user_pkey; Type: CONSTRAINT; Schema: public; Owner: pguser
--

ALTER TABLE ONLY public.app_user
    ADD CONSTRAINT app_user_pkey PRIMARY KEY (id);


--
-- Name: payment_receipt payment_receipt_pkey; Type: CONSTRAINT; Schema: public; Owner: pguser
--

ALTER TABLE ONLY public.payment_receipt
    ADD CONSTRAINT payment_receipt_pkey PRIMARY KEY (id);


--
-- Name: privilege privilege_pkey; Type: CONSTRAINT; Schema: public; Owner: pguser
--

ALTER TABLE ONLY public.privilege
    ADD CONSTRAINT privilege_pkey PRIMARY KEY (id);


--
-- Name: product product_pkey; Type: CONSTRAINT; Schema: public; Owner: pguser
--

ALTER TABLE ONLY public.product
    ADD CONSTRAINT product_pkey PRIMARY KEY (id);


--
-- Name: purchase purchase_pkey; Type: CONSTRAINT; Schema: public; Owner: pguser
--

ALTER TABLE ONLY public.purchase
    ADD CONSTRAINT purchase_pkey PRIMARY KEY (id);


--
-- Name: purchase_products purchase_products_pkey; Type: CONSTRAINT; Schema: public; Owner: pguser
--

ALTER TABLE ONLY public.purchase_products
    ADD CONSTRAINT purchase_products_pkey PRIMARY KEY (id);


--
-- Name: role role_pkey; Type: CONSTRAINT; Schema: public; Owner: pguser
--

ALTER TABLE ONLY public.role
    ADD CONSTRAINT role_pkey PRIMARY KEY (id);


--
-- Name: stock stock_pkey; Type: CONSTRAINT; Schema: public; Owner: pguser
--

ALTER TABLE ONLY public.stock
    ADD CONSTRAINT stock_pkey PRIMARY KEY (id);


--
-- Name: stock_products stock_products_pkey; Type: CONSTRAINT; Schema: public; Owner: pguser
--

ALTER TABLE ONLY public.stock_products
    ADD CONSTRAINT stock_products_pkey PRIMARY KEY (id);


--
-- Name: app_user uk_3k4cplvh82srueuttfkwnylq0; Type: CONSTRAINT; Schema: public; Owner: pguser
--

ALTER TABLE ONLY public.app_user
    ADD CONSTRAINT uk_3k4cplvh82srueuttfkwnylq0 UNIQUE (username);


--
-- Name: purchase fk2s9r1y9ynnw3qxxveqcbhumah; Type: FK CONSTRAINT; Schema: public; Owner: pguser
--

ALTER TABLE ONLY public.purchase
    ADD CONSTRAINT fk2s9r1y9ynnw3qxxveqcbhumah FOREIGN KEY (user_id) REFERENCES public.app_user(id);


--
-- Name: roles_privileges fk5yjwxw2gvfyu76j3rgqwo685u; Type: FK CONSTRAINT; Schema: public; Owner: pguser
--

ALTER TABLE ONLY public.roles_privileges
    ADD CONSTRAINT fk5yjwxw2gvfyu76j3rgqwo685u FOREIGN KEY (privilege_id) REFERENCES public.privilege(id);


--
-- Name: user_roles fk6fql8djp64yp4q9b3qeyhr82b; Type: FK CONSTRAINT; Schema: public; Owner: pguser
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT fk6fql8djp64yp4q9b3qeyhr82b FOREIGN KEY (user_id) REFERENCES public.app_user(id);


--
-- Name: purchase_products fk7tk8j2j2cful59sidlhleawr1; Type: FK CONSTRAINT; Schema: public; Owner: pguser
--

ALTER TABLE ONLY public.purchase_products
    ADD CONSTRAINT fk7tk8j2j2cful59sidlhleawr1 FOREIGN KEY (product_id) REFERENCES public.product(id);


--
-- Name: purchase_products fk8xefc7i9lw99fc3iyed7u1rsv; Type: FK CONSTRAINT; Schema: public; Owner: pguser
--

ALTER TABLE ONLY public.purchase_products
    ADD CONSTRAINT fk8xefc7i9lw99fc3iyed7u1rsv FOREIGN KEY (stock_id) REFERENCES public.stock(id);


--
-- Name: roles_privileges fk9h2vewsqh8luhfq71xokh4who; Type: FK CONSTRAINT; Schema: public; Owner: pguser
--

ALTER TABLE ONLY public.roles_privileges
    ADD CONSTRAINT fk9h2vewsqh8luhfq71xokh4who FOREIGN KEY (role_id) REFERENCES public.role(id);


--
-- Name: purchase_products fkquuf4xmoqfcnww0m8dl69wef0; Type: FK CONSTRAINT; Schema: public; Owner: pguser
--

ALTER TABLE ONLY public.purchase_products
    ADD CONSTRAINT fkquuf4xmoqfcnww0m8dl69wef0 FOREIGN KEY (purchase_id) REFERENCES public.purchase(id);


--
-- Name: stock_products fkqwn73jr13scg980poo52uq3by; Type: FK CONSTRAINT; Schema: public; Owner: pguser
--

ALTER TABLE ONLY public.stock_products
    ADD CONSTRAINT fkqwn73jr13scg980poo52uq3by FOREIGN KEY (stock_id) REFERENCES public.stock(id);


--
-- Name: stock_products fkr5r1qyv04mnmyeovsmi2um1l8; Type: FK CONSTRAINT; Schema: public; Owner: pguser
--

ALTER TABLE ONLY public.stock_products
    ADD CONSTRAINT fkr5r1qyv04mnmyeovsmi2um1l8 FOREIGN KEY (product_id) REFERENCES public.product(id);


--
-- Name: user_roles fkrhfovtciq1l558cw6udg0h0d3; Type: FK CONSTRAINT; Schema: public; Owner: pguser
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT fkrhfovtciq1l558cw6udg0h0d3 FOREIGN KEY (role_id) REFERENCES public.role(id);


--
-- Name: purchase purchase_stock_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: pguser
--

ALTER TABLE ONLY public.purchase
    ADD CONSTRAINT purchase_stock_id_fk FOREIGN KEY (stock_id) REFERENCES public.stock(id);


--
-- PostgreSQL database dump complete
--

